"""Backward compatibility shim - import from integrations.linear.config instead."""

from integrations.linear.config import *  # noqa: F403
