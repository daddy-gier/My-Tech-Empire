"""Backward compatibility shim - import from prompts_pkg.prompts instead."""

from prompts_pkg.prompts import *  # noqa: F403
