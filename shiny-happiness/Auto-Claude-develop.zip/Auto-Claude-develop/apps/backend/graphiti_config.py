"""Backward compatibility shim - import from integrations.graphiti.config instead."""

from integrations.graphiti.config import *  # noqa: F403
