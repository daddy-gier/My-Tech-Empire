"""Backward compatibility shim - import from core.agent instead."""

from core.agent import *  # noqa: F403
