"""Backward compatibility shim - import from security.scan_secrets instead."""

from security.scan_secrets import *  # noqa: F403
