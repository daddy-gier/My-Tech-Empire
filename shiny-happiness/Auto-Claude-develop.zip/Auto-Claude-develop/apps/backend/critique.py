"""Backward compatibility shim - import from spec.critique instead."""

from spec.critique import *  # noqa: F403
