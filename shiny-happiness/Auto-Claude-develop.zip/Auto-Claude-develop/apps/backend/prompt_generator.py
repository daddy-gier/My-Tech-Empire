"""Backward compatibility shim - import from prompts_pkg.prompt_generator instead."""

from prompts_pkg.prompt_generator import *  # noqa: F403
