import warnings

__version__ = "2.6"
__description__ = "Typst-based CV/resume generator for academics and engineers."


warnings.filterwarnings("ignore")  # Ignore Pydantic warnings
