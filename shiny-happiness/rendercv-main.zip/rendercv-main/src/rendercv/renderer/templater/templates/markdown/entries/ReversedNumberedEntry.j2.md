1. {{entry.reversed_number}}
