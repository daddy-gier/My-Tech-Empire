// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

// Stub header to satisfy d3d12.h include
#pragma once