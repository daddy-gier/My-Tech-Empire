// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

// Stub header to satisfy d3d12.h include. Unconditionally light up all APIs.
#pragma once
#define WINAPI_FAMILY_PARTITION(Partitions) 1